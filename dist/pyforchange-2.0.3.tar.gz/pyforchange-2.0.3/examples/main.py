from pyforchange.egg import eggConsole

eggConsole()

"""
document=Document("template")
document.addTag("h1","Hi","aqui")
document.write("xd","2")

covid=Repo("CovidPlot")
cp=covid.pull("covidplot","CovidData")
#pull("CovidPlot")
covidata=cp.CovidData
c=covidata()
c.plot
"""