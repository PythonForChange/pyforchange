def settings(command: str,param):
  t=""
  if command=="inject":
    t=param+"\n"
  return t