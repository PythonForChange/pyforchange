from pyforchange.egg.resources.modules import Repo

NQS=Repo("NQS")
nqs=NQS.pull("nqs")