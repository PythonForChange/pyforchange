from pyforchange.nqs.developer.write import write
from pyforchange.nqs.developer.run import run

_author="eanorambuena"
_author_email="eanorambuena@uc.cl"

nqsCommands=[
  "host",
  "shots",
  "hist",
  "draw",
  "inject",
  "function",
  "clear",
  "delay"
]

consoleCommands=[
  "display",
  "compile",
  "save",
  "run",
  "end",
  "delay"
]